import hashlib
import hmac
import json
import os
import tempfile
import unittest
from unittest.mock import patch

DB_FILE = tempfile.NamedTemporaryFile(delete=False).name
os.environ["WEBHOOK_DB_PATH"] = DB_FILE
os.environ["WEBHOOK_SIGNING_SECRET"] = "test-secret"

import database
import app as app_module
import worker

class WebhookApiTests(unittest.TestCase):
    def setUp(self):
        with database.get_db() as conn:
            conn.execute("DELETE FROM attempts")
            conn.execute("DELETE FROM events")
            conn.execute("DELETE FROM sqlite_sequence WHERE name IN ('events','attempts')")
        self.client = app_module.app.test_client()

    @patch("worker._post_webhook", return_value=(204, None))
    def test_create_event_is_queued_for_background_worker(self, mocked_post):
        response = self.client.post("/events", json={
            "type": "user.signup",
            "payload": {"user_id": 123},
            "webhook_url": "https://example.com/hook",
        })
        self.assertEqual(response.status_code, 201)
        body = response.get_json()
        self.assertEqual(body["status"], "pending")
        self.assertEqual(body["attempts"], [])
        mocked_post.assert_not_called()

    @patch("worker._post_webhook", return_value=(204, None))
    def test_worker_success_records_attempt(self, mocked_post):
        with database.get_db() as conn:
            cur = conn.execute("""INSERT INTO events(type,payload,webhook_url,status,created_at,attempt_count)
                VALUES('test','{}','https://example.com','pending','now',0)""")
            event_id = cur.lastrowid
            event = dict(conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone())
        worker.process_event(event)
        with database.get_db() as conn:
            row = conn.execute("SELECT status FROM events WHERE id=?", (event_id,)).fetchone()
            attempt = conn.execute("SELECT http_status,outcome FROM attempts WHERE event_id=?", (event_id,)).fetchone()
        self.assertEqual(row["status"], "delivered")
        self.assertEqual(attempt["http_status"], 204)
        self.assertEqual(attempt["outcome"], "success")

    @patch("worker._post_webhook", return_value=(500, "HTTP 500"))
    def test_failure_schedules_retry_and_records_attempt(self, mocked_post):
        response = self.client.post("/events", json={
            "type": "payment.failed",
            "payload": {"payment_id": "p1"},
            "webhook_url": "https://example.com/hook",
        })
        self.assertEqual(response.status_code, 201)
        body = response.get_json()
        self.assertEqual(body["status"], "pending")
        self.assertEqual(body["attempts"][0]["outcome"], "failed")
        with database.get_db() as conn:
            row = conn.execute("SELECT attempt_count, next_attempt_at FROM events WHERE id=?", (body["id"],)).fetchone()
        self.assertEqual(row["attempt_count"], 1)
        self.assertIsNotNone(row["next_attempt_at"])

    def test_get_missing_event(self):
        self.assertEqual(self.client.get("/events/99999").status_code, 404)

    @patch("worker._post_webhook", return_value=(500, "HTTP 500"))
    def test_manual_retry_only_for_dead_event(self, mocked_post):
        with database.get_db() as conn:
            cur = conn.execute("""INSERT INTO events(type,payload,webhook_url,status,created_at,attempt_count)
                VALUES('test','{}','https://example.com','pending','now',0)""")
            event_id = cur.lastrowid
        response = self.client.post(f"/events/{event_id}/retry")
        self.assertEqual(response.status_code, 400)

    def test_hmac_signature_verifiable(self):
        body = b'{"hello":"world"}'
        actual = worker.signature_for(body, b"test-secret")
        expected = "sha256=" + hmac.new(b"test-secret", body, hashlib.sha256).hexdigest()
        self.assertEqual(actual, expected)

if __name__ == "__main__":
    unittest.main()
