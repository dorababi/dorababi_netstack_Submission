import os
from flask import Flask, jsonify, request
from database import init_db, get_db
from worker import enqueue_event, retry_dead_event

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False
init_db()

def event_json(row, include_attempts=False):
    event = {
        "id": row["id"],
        "type": row["type"],
        "payload": __import__("json").loads(row["payload"]),
        "webhook_url": row["webhook_url"],
        "status": row["status"],
        "created_at": row["created_at"],
    }
    if include_attempts:
        with get_db() as conn:
            attempts = conn.execute(
                """SELECT attempted_at, http_status, outcome
                   FROM attempts WHERE event_id = ? ORDER BY id ASC""",
                (row["id"],),
            ).fetchall()
        event["attempts"] = [
            {
                "attempted_at": a["attempted_at"],
                "http_status": a["http_status"],
                "outcome": a["outcome"],
            }
            for a in attempts
        ]
    return event

@app.post("/events")
def create_event():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="Request body must be a JSON object"), 400
    missing = [key for key in ("type", "payload", "webhook_url") if key not in data]
    if missing:
        return jsonify(error="Missing required fields", fields=missing), 400
    if not isinstance(data["type"], str) or not data["type"].strip():
        return jsonify(error="type must be a non-empty string"), 400
    if not isinstance(data["payload"], (dict, list)):
        return jsonify(error="payload must be a JSON object or array"), 400
    if not isinstance(data["webhook_url"], str) or not data["webhook_url"].startswith(("http://", "https://")):
        return jsonify(error="webhook_url must be an HTTP(S) URL"), 400

    event_id = enqueue_event(data["type"].strip(), data["payload"], data["webhook_url"])
    with get_db() as conn:
        row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    return jsonify(event_json(row, include_attempts=True)), 201

@app.get("/events")
def list_events():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM events ORDER BY created_at DESC, id DESC").fetchall()
    return jsonify([event_json(row, include_attempts=True) for row in rows]), 200

@app.get("/events/<int:event_id>")
def get_event(event_id):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if row is None:
        return jsonify(error="Event not found"), 404
    return jsonify(event_json(row, include_attempts=True)), 200

@app.post("/events/<int:event_id>/retry")
def retry_event(event_id):
    result = retry_dead_event(event_id)
    if result == "not_found":
        return jsonify(error="Event not found"), 404
    if result == "not_dead":
        return jsonify(error="Only dead events can be manually retried"), 400
    with get_db() as conn:
        row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    return jsonify(event_json(row, include_attempts=True)), 200

@app.get("/health")
def health():
    return jsonify(status="ok"), 200

if __name__ == "__main__":
    # Development convenience only. In production, run `python worker.py` separately.
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
