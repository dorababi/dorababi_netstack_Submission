# Nestack Webhook Delivery Engine (Python + SQLite)

A webhook event API and a separate background worker. Retry scheduling and polling are implemented directly with Python and SQLite; **no queue library is used**.

## Features

- `POST /events`: validate and persist an event, then make the first delivery attempt immediately.
- `GET /events`: list events with delivery attempt history.
- `GET /events/<id>`: fetch one event and full attempt history.
- `POST /events/<id>/retry`: manually restart a dead event's delivery cycle; returns `400` unless it is dead.
- HMAC-SHA256 in `X-Webhook-Signature`.
- Non-2xx responses, HTTP errors, timeouts, and network errors are failures.
- SQLite persists events, attempts, and due retry timestamps.
- Worker runs independently and continues polling even after individual errors.

## Requirements

- Python 3.10+
- pip

## Setup

```bash
python -m venv .venv
# Windows PowerShell:
.venv\\Scripts\\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Set a signing secret before starting either process. Use the same value for API and worker. For example:

```bash
# macOS/Linux
export WEBHOOK_SIGNING_SECRET='replace-with-a-long-random-secret'
# Windows PowerShell
$env:WEBHOOK_SIGNING_SECRET='replace-with-a-long-random-secret'
```

Optional environment variables:

- `WEBHOOK_DB_PATH`: SQLite database path (default `webhooks.db` beside `database.py`).
- `WEBHOOK_TIMEOUT_SECONDS`: HTTP request timeout (default 10 seconds).
- `WORKER_POLL_SECONDS`: worker polling sleep (default 0.5 seconds).
- `PORT`: API port (default 5000).

The default signing key is for local development only. Always set a strong secret in deployment. Do not commit `.env` or secrets.

## Run the API and worker

Open two terminals in the project directory and activate the virtual environment in each.

Terminal 1:

```bash
python app.py
```

Terminal 2:

```bash
python worker.py
```

API health check: `GET http://localhost:5000/health`.

The API persists the event and returns immediately. The independent worker polls every 0.5 seconds and attempts newly queued events on its next poll, so first delivery is prompt and is performed by the background process rather than inside the API request.

## API examples

Create an event:

```bash
curl -X POST http://localhost:5000/events \\
  -H 'Content-Type: application/json' \\
  -d '{
    "type": "user.signup",
    "payload": {"user_id": "u_123", "email": "person@example.com"},
    "webhook_url": "https://your-server.example/webhooks"
  }'
```

List events:

```bash
curl http://localhost:5000/events
```

Get event and attempt history:

```bash
curl http://localhost:5000/events/1
```

Manually retry a dead event:

```bash
curl -X POST http://localhost:5000/events/1/retry
```

A created event response is `201`; list and details are `200`; invalid requests return `400`; unknown IDs return `404`; retrying a non-dead event returns `400`.

## Event and attempt shape

Each event includes `id`, `type`, `payload`, `webhook_url`, `status`, `created_at`, and `attempts`. Status is one of `pending`, `delivered`, `failed`, or `dead`. Each attempt contains `attempted_at`, `http_status` (null when no HTTP response was received), and `outcome` (`success` or `failed`). Attempt records are chronological.

`failed` is included as a status value for API compatibility; automatic delivery failures remain `pending` while a retry is scheduled and become `dead` after the fourth failed attempt. Successful delivery sets `delivered`.

## Retry schedule

- Attempt 1: immediately at ingestion.
- After attempt 1 fails: wait 30 seconds.
- After attempt 2 fails: wait 5 minutes.
- After attempt 3 fails: wait 30 minutes.
- After attempt 4 fails: mark `dead`; no automatic retries remain.

Any 2xx response is success. Non-2xx, timeout, connection failure, and other URL/network errors are failures. `next_attempt_at` is stored in SQLite as a Unix timestamp. The worker polls every 0.5 seconds, so it does not intentionally dispatch a retry before its due timestamp; polling adds up to roughly one poll interval of scheduling latency (plus time spent processing another delivery).

A manual retry of a dead event resets its automatic attempt counter to start a fresh four-attempt cycle, while retaining all prior attempt-history rows.

## HMAC signature: signing and verification

The signature header is:

```text
X-Webhook-Signature: sha256=<lowercase-hex-digest>
```

The digest is HMAC-SHA256 over the exact UTF-8 bytes of the outgoing JSON request body, using `WEBHOOK_SIGNING_SECRET` as the shared key. A receiving server must compute the HMAC over the **raw request body bytes**, not a re-serialized JSON object, then compare signatures using a constant-time comparison.

Python receiver example:

```python
import hashlib
import hmac
from flask import request, abort

SHARED_SECRET = b"replace-with-a-long-random-secret"

def verify_webhook():
    supplied = request.headers.get("X-Webhook-Signature", "")
    expected = "sha256=" + hmac.new(
        SHARED_SECRET, request.get_data(), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(supplied, expected):
        abort(401)
```

For production, use HTTPS so payloads and signatures are protected in transit. Rotate secrets deliberately and coordinate the same key with the receiver.

## Tests

```bash
python -m unittest discover -s tests -v
```

Tests use a temporary SQLite database and mock outbound HTTP delivery. They cover successful delivery, failure/retry state, missing events, manual retry validation, and signature calculation.

## Restart behavior and durability

Events, attempts, attempt counters, and scheduled retry timestamps are persisted in SQLite. After an API or worker restart, the worker resumes due pending events from the database; it does not reset their retry delay. A retry whose due time passes while the worker is down will be attempted after the worker starts again.

The worker uses a short lease to reduce duplicate concurrent delivery. If the worker crashes after sending a request but before recording the result, the request may be delivered again after the lease expires; webhook delivery is therefore **at-least-once**, not exactly-once. Receiving endpoints should be idempotent. A request already in flight during a crash can have an ambiguous result.

## Deployment notes

Deploy the API and worker as **two long-running processes/services** sharing the same persistent SQLite file and identical environment variables. The SQLite file must live on a persistent disk; ephemeral filesystems lose data on redeploy/restart. Do not run multiple unrelated instances with separate local disks. If the hosting platform cannot provide a shared persistent filesystem or separate worker process, use a platform that can (or migrate storage to a shared database).

Example process commands:

- Web service: `gunicorn app:app`
- Worker service: `python worker.py`

If using Gunicorn, add `gunicorn` to `requirements.txt` (it is intentionally not required for local development). Configure `WEBHOOK_DB_PATH` to a persistent mounted disk path and set `WEBHOOK_SIGNING_SECRET` in the platform's secret/environment settings. Ensure the worker is a separate always-on service, not a request-triggered task.

No live deployment URL is included in this source bundle because deployment requires your hosting account and configured persistent storage. Once deployed, add the actual URL here and in your private repository description.

## Private GitHub submission checklist

1. Create a **private** repository named `<yourName>_Nestack_Submission` (for example, `babi_Nestack_Submission`).
2. From this directory, initialize and push the code:

   ```bash
   git init
   git add .
   git commit -m "Build webhook delivery engine assessment"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<yourName>_Nestack_Submission.git
   git push -u origin main
   ```

3. In GitHub repository **Settings → Collaborators**, invite:
   - `bishal@nestack.com`
   - `sannidhya@nestack.com`
   - `sanjay@nestack.com`
4. Confirm repository visibility is **Private**. Do not make it public.
5. Create a ZIP of the project, excluding `.venv`, `.git`, secrets, and generated database files.
6. Deploy the API and worker, then replace the deployment placeholder with the real public API base URL.
7. Submit the private repository URL, ZIP, deployment URL, and any required non-secret access details through the assessment platform. Never share the signing secret in the repository or README.

## Scope and production hardening

This is an assessment implementation. Before production use, add SSRF defenses (restrict webhook targets and block loopback/private/link-local IP ranges, including DNS-rebinding protections), request authentication/rate limiting, payload size limits, structured logging/metrics, secret rotation, and stronger multi-worker claiming semantics. Do not expose this unauthenticated event-ingestion API publicly without appropriate controls.
