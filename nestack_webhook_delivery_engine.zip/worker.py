"""Custom SQLite-polling webhook worker. No queue/scheduler library is used."""
import hashlib
import hmac
import json
import os
import time
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from database import get_db, init_db

RETRY_DELAYS = (30, 5 * 60, 30 * 60)
REQUEST_TIMEOUT_SECONDS = float(os.getenv("WEBHOOK_TIMEOUT_SECONDS", "10"))
POLL_INTERVAL_SECONDS = float(os.getenv("WORKER_POLL_SECONDS", "0.5"))
SIGNING_SECRET = os.getenv("WEBHOOK_SIGNING_SECRET", "dev-only-change-me").encode("utf-8")
MAX_ATTEMPTS = 1 + len(RETRY_DELAYS)

def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def signature_for(body: bytes, secret: bytes = None) -> str:
    """Return lowercase hex HMAC-SHA256 of the exact request body bytes."""
    key = secret if secret is not None else SIGNING_SECRET
    digest = hmac.new(key, body, hashlib.sha256).hexdigest()
    return "sha256=" + digest

def _claim_due_event():
    """Atomically lease one due event so multiple workers do not normally double-send it."""
    now = time.time()
    with get_db() as conn:
        row = conn.execute("""
            SELECT * FROM events
            WHERE status = 'pending'
              AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
              AND (lease_until IS NULL OR lease_until < ?)
            ORDER BY COALESCE(next_attempt_at, 0), id
            LIMIT 1
        """, (now, now)).fetchone()
        if row is None:
            return None
        conn.execute("UPDATE events SET lease_until = ? WHERE id = ?", (now + REQUEST_TIMEOUT_SECONDS + 15, row["id"]))
        return dict(row)

def _post_webhook(url: str, body: bytes):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None, "invalid webhook URL"
    req = Request(
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Webhook-Signature": signature_for(body),
            "User-Agent": "Nestack-Webhook-Delivery-Engine/1.0",
        },
    )
    try:
        with urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            status = response.getcode()
            return status, None if 200 <= status < 300 else f"HTTP {status}"
    except HTTPError as exc:
        return exc.code, f"HTTP {exc.code}"
    except (URLError, TimeoutError, OSError) as exc:
        return None, str(exc)

def process_event(event):
    """Perform one attempt and persist attempt history plus the next state."""
    body = json.dumps(json.loads(event["payload"]), separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    status_code, error = _post_webhook(event["webhook_url"], body)
    success = status_code is not None and 200 <= status_code < 300
    attempted_at = utc_now()

    with get_db() as conn:
        current = conn.execute("SELECT * FROM events WHERE id = ?", (event["id"],)).fetchone()
        if current is None or current["status"] != "pending":
            return
        attempt_number = current["attempt_count"] + 1
        conn.execute("""
            INSERT INTO attempts(event_id, attempted_at, http_status, outcome, error)
            VALUES (?, ?, ?, ?, ?)
        """, (event["id"], attempted_at, status_code, "success" if success else "failed", error))
        if success:
            conn.execute("""
                UPDATE events SET status='delivered', attempt_count=?, next_attempt_at=NULL, lease_until=NULL
                WHERE id=?
            """, (attempt_number, event["id"]))
        elif attempt_number >= MAX_ATTEMPTS:
            conn.execute("""
                UPDATE events SET status='dead', attempt_count=?, next_attempt_at=NULL, lease_until=NULL
                WHERE id=?
            """, (attempt_number, event["id"]))
        else:
            delay = RETRY_DELAYS[attempt_number - 1]
            conn.execute("""
                UPDATE events SET status='pending', attempt_count=?, next_attempt_at=?, lease_until=NULL
                WHERE id=?
            """, (attempt_number, time.time() + delay, event["id"]))

def enqueue_event(event_type, payload, webhook_url):
    init_db()
    created_at = utc_now()
    payload_json = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    with get_db() as conn:
        cursor = conn.execute("""
            INSERT INTO events(type, payload, webhook_url, status, created_at, attempt_count, next_attempt_at)
            VALUES (?, ?, ?, 'pending', ?, 0, NULL)
        """, (event_type, payload_json, webhook_url, created_at))
        event_id = cursor.lastrowid
    # The independent worker sees next_attempt_at=NULL and picks this up on its
    # next poll. Delivery never runs inside an API request handler.
    return event_id

def _claim_event_by_id(event_id):
    now = time.time()
    with get_db() as conn:
        row = conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
        if row is None or row["status"] != "pending" or row["attempt_count"] != 0:
            return None
        conn.execute("UPDATE events SET lease_until=? WHERE id=?", (now + REQUEST_TIMEOUT_SECONDS + 15, event_id))
        return dict(row)

def retry_dead_event(event_id):
    with get_db() as conn:
        row = conn.execute("SELECT status FROM events WHERE id=?", (event_id,)).fetchone()
        if row is None:
            return "not_found"
        if row["status"] != "dead":
            return "not_dead"
        # Manual retry begins a fresh retry cycle but retains complete historical attempts.
        conn.execute("""
            UPDATE events SET status='pending', attempt_count=0, next_attempt_at=NULL, lease_until=NULL
            WHERE id=?
        """, (event_id,))
    return "queued"

def run_worker():
    init_db()
    print("Webhook worker started; polling SQLite for due events.")
    while True:
        try:
            event = _claim_due_event()
            if event:
                process_event(event)
            else:
                time.sleep(POLL_INTERVAL_SECONDS)
        except KeyboardInterrupt:
            print("Worker stopped.")
            break
        except Exception as exc:
            # Keep the worker alive if a single event or transient DB error fails.
            print(f"Worker error: {exc!r}")
            time.sleep(POLL_INTERVAL_SECONDS)

if __name__ == "__main__":
    run_worker()
