import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.getenv("WEBHOOK_DB_PATH", os.path.join(os.path.dirname(__file__), "webhooks.db"))

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                payload TEXT NOT NULL,
                webhook_url TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('pending','delivered','failed','dead')),
                created_at TEXT NOT NULL,
                attempt_count INTEGER NOT NULL DEFAULT 0,
                next_attempt_at REAL,
                lease_until REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                attempted_at TEXT NOT NULL,
                http_status INTEGER,
                outcome TEXT NOT NULL CHECK(outcome IN ('success','failed')),
                error TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_due ON events(status, next_attempt_at)")
